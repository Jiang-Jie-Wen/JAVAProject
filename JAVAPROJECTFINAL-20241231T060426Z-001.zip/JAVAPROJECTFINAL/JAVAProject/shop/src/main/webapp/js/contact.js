window.onload = function(){
    loadFooter();
    loadNavbar();
    loadFloatingBtn();
}