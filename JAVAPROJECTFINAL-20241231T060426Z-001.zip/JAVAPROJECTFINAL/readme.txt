CreateUser.sql 建立使用者 或 直接創
帳號:javaproject
密碼:1qaz@wsx

CreateDatabases 建立資料庫
沒內容 主要只要加
admin 創建管理者(至少一個) 跟 categories 創建物品種類

三個war檔加到tomcat的webapps 並且創立一個空資料夾 picture >> 放圖片用的
就放在webapps底下就可以